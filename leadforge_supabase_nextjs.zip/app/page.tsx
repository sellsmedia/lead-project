'use client'

import React, { useState } from 'react'
import { createClient } from '@/utils/supabase/client'

export default function Home() {
  const supabase = createClient()

  const [isModalOpen, setIsModalOpen] = useState(false)
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState<{ text: string; type: 'error' | 'success' } | null>(null)
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null)

  const openModal = (mode: 'login' | 'signup') => {
    setEmail('')
    setPassword('')
    setMessage(null)
    setAuthMode(mode)
    setIsModalOpen(true)
  }

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setMessage(null)

    try {
      if (authMode === 'signup') {
        const { data, error } = await supabase.auth.signUp({ email, password })
        if (error) throw error
        
        if (data.user && !data.session) {
          setMessage({ text: 'Success! Please check your email to verify your registration.', type: 'success' })
        } else {
          setMessage({ text: 'Account created! Redirecting to dashboard...', type: 'success' })
          setTimeout(() => { window.location.href = '/dashboard' }, 1500)
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error

        setMessage({ text: 'Welcome back! Redirecting...', type: 'success' })
        setTimeout(() => { window.location.href = '/dashboard' }, 1500)
      }
    } catch (err: any) {
      setMessage({ text: err.message || 'Something went wrong', type: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white text-slate-900 font-sans antialiased relative min-h-screen">
      <header className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <span className="text-2xl font-extrabold text-[#004e9a]">LeadForge</span>
            <span className="bg-[#22c55e] text-white text-[10px] font-bold px-1.5 py-0.5 rounded-md uppercase tracking-wider">Live</span>
          </div>
        </div>
        <nav className="hidden md:flex items-center space-x-8 text-sm font-medium text-slate-600">
          <a className="hover:text-[#0052cc] transition-colors" href="#">Features</a>
          <a className="hover:text-[#0052cc] transition-colors" href="#">How It Works</a>
          <a className="hover:text-[#0052cc] transition-colors" href="#pricing-section">Pricing</a>
          <a className="hover:text-[#0052cc] transition-colors" href="#">FAQ</a>
          <a className="hover:text-[#0052cc] transition-colors" href="#">Blog</a>
        </nav>
        <div className="flex items-center space-x-4">
          <button onClick={() => openModal('login')} className="px-4 py-2 text-sm font-semibold border border-[#0052cc] text-[#0052cc] rounded-lg hover:bg-[#f0f9ff] transition-colors">
            Login
          </button>
          <button onClick={() => openModal('signup')} className="px-4 py-2 text-sm font-semibold bg-[#0052cc] text-white rounded-lg hover:bg-[#0747a6] transition-colors flex items-center gap-1">
            Sign Up Free <span className="text-lg">→</span>
          </button>
        </div>
      </header>

      <main className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2 space-y-8">
            <h1 className="text-5xl lg:text-6xl font-extrabold text-slate-900 leading-[1.1]">
              Real businesses.<br/>
              No website.<br/>
              <span className="text-[#0052cc]">Ready to buy yours.</span>
            </h1>
            <p className="text-lg text-slate-600 max-w-lg leading-relaxed">
              Verified Google Business Profiles pulled live from our Apify-powered crawler. Filter, unlock and connect with businesses that are actively looking for a website.
            </p>
            <div className="flex flex-wrap gap-4">
              <button onClick={() => openModal('signup')} className="px-8 py-4 bg-[#0052cc] text-white font-bold rounded-lg hover:bg-[#0747a6] transition-all flex items-center gap-2">
                Start Finding Leads <span className="text-lg">→</span>
              </button>
              <button className="px-8 py-4 bg-white border border-slate-200 text-[#0052cc] font-bold rounded-lg hover:bg-slate-50 transition-all flex items-center gap-2 shadow-sm">
                <svg className="w-5 h-5 fill-[#0052cc]" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"></path></svg>
                View Demo
              </button>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6">
              <div className="flex items-start gap-2">
                <span className="text-[#0052cc] mt-1">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path></svg>
                </span>
                <div>
                  <p className="text-sm font-bold text-slate-800">100% Verified Leads</p>
                  <p className="text-[12px] text-slate-500">Real & active businesses</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-[#0052cc] mt-1">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M13 10V3L4 14h7v7l9-11h-7z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path></svg>
                </span>
                <div>
                  <p className="text-sm font-bold text-slate-800">Live Data from Apify</p>
                  <p className="text-[12px] text-slate-500">Fresh & accurate</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-[#0052cc] mt-1">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path></svg>
                </span>
                <div>
                  <p className="text-sm font-bold text-slate-800">Pay Only for Leads</p>
                  <p className="text-[12px] text-slate-500">Unlock with credits</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:w-1/2 relative">
            <div className="rounded-2xl overflow-hidden bg-slate-50 border border-slate-100 shadow-[0_20px_50px_rgba(0,0,0,0.1)]">
              <img alt="LeadForge Live Dashboard Preview" className="w-full h-auto block" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD5pbt-IiIswWFQCS3G6-Q2XpVTwO75RFi3UTBNNaoLJpSO8RDAWs7Kzm7KWkDW6qm20LFuKkJvGblDr6fJBOSbJdITERq7MO_Y4HkZ0m5ewucJvZs11pMe9SeXHkeysGAJlv0tuxa6l4Cd228K01khtp9BN6vp-V1IqjsdnM0pSMRTnxjL_ZRL-ISm1M1MnxIuJfQnqG1E1Xe59XNgohrRRquu28ZCBtmlUW0C-q15yL1Ojl9VMHs_evI6ZqTBjv5VkD-_MIubfvQ"/>
            </div>
          </div>
        </div>
      </main>

      <section className="bg-white py-20 border-t border-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="inline-block px-4 py-1.5 bg-[#f0f9ff] text-[#0052cc] text-xs font-bold uppercase tracking-widest rounded-full mb-4">Features</span>
          <h2 className="text-4xl font-extrabold text-slate-900 mb-4">Everything you need to find high-converting leads</h2>
          <p className="text-slate-500 max-w-2xl mx-auto mb-16">Powerful features to help you discover, filter and connect with businesses that are ready for your services.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="p-8 bg-white border border-slate-100 rounded-xl shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="w-12 h-12 bg-blue-50 text-[#0052cc] rounded-lg flex items-center justify-center mb-6">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path></svg>
              </div>
              <h3 className="text-xl font-bold mb-3">No Website Leads</h3>
              <p className="text-slate-500 text-sm leading-relaxed">Find businesses that don't have a website and are missing out on customers.</p>
            </div>
            <div className="p-8 bg-white border border-slate-100 rounded-xl shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="w-12 h-12 bg-green-50 text-[#22c55e] rounded-lg flex items-center justify-center mb-6">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path></svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Smart Filters</h3>
              <p className="text-slate-500 text-sm leading-relaxed">Filter by country, city, niche, rating, reviews and more to get high-quality leads.</p>
            </div>
            <div className="p-8 bg-white border border-slate-100 rounded-xl shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="w-12 h-12 bg-purple-50 text-purple-600 rounded-lg flex items-center justify-center mb-6">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path></svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Instant Unlock</h3>
              <p className="text-slate-500 text-sm leading-relaxed">Unlock full contact details instantly using credits. Pay only for what you need.</p>
            </div>
            <div className="p-8 bg-white border border-slate-100 rounded-xl shadow-sm hover:shadow-md transition-shadow text-left">
              <div className="w-12 h-12 bg-orange-50 text-orange-500 rounded-lg flex items-center justify-center mb-6">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"></path></svg>
              </div>
              <h3 className="text-xl font-bold mb-3">Lead History</h3>
              <p className="text-slate-500 text-sm leading-relaxed">All your unlocked leads are saved forever and ready for your follow-ups.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-[#f8fafc] py-20" id="pricing-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
            <div className="lg:w-1/3">
              <h2 className="text-3xl font-extrabold text-slate-900 mb-4">Simple, credit-based pricing</h2>
              <p className="text-slate-500">Buy credits once and unlock leads as you go. No monthly subscriptions.</p>
            </div>
            <div className="lg:w-2/3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { name: 'Starter', price: '$19', credits: '1,000 credits', popular: false },
                { name: 'Pro', price: '$49', credits: '3,000 credits', popular: true },
                { name: 'Growth', price: '$99', credits: '10,000 credits', popular: false },
                { name: 'Business', price: '$199', credits: '25,000 credits', popular: false }
              ].map((plan, idx) => (
                <div 
                  key={idx}
                  onClick={() => setSelectedPlan(idx)}
                  className={`bg-white p-6 rounded-xl border relative text-center transition-all duration-200 cursor-pointer ${
                    selectedPlan === idx 
                      ? 'border-[#0052cc] scale-105 z-10 shadow-[0_10px_25px_rgba(0,82,204,0.15)]' 
                      : plan.popular ? 'border-[#0052cc] scale-105' : 'border-slate-200'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#0052cc] text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-tighter">Most Popular</div>
                  )}
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">{plan.name}</p>
                  <p className="text-4xl font-extrabold mb-1">{plan.price}</p>
                  <p className="text-sm text-slate-500 mb-6">{plan.credits}</p>
                  <button 
                    onClick={(e) => { e.stopPropagation(); openModal('signup') }}
                    className={`w-full py-2 font-bold rounded-lg text-sm transition-colors ${
                      plan.popular || selectedPlan === idx ? 'bg-[#0052cc] text-white hover:bg-[#0747a6]' : 'border border-[#0052cc] text-[#0052cc] hover:bg-[#f0f9ff]'
                    }`}
                  >
                    {selectedPlan === idx ? 'Selected' : 'Get Started'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 pt-10">
        <div className="bg-[#0052cc] rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between text-white overflow-hidden relative">
          <div className="relative z-10">
            <h2 className="text-3xl font-bold mb-4">Ready to find your next clients?</h2>
            <p className="text-blue-100">Start searching now and connect with businesses that need you.</p>
          </div>
          <div className="mt-8 md:mt-0 flex flex-wrap gap-4 relative z-10">
            <button className="px-6 py-3 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold rounded-lg flex items-center gap-2 transition-all">
              <svg className="w-5 h-5 fill-white" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"></path></svg>
              View Demo
            </button>
            <button onClick={() => openModal('signup')} className="px-6 py-3 bg-white text-[#0052cc] font-bold rounded-lg flex items-center gap-2 hover:bg-blue-50 transition-all">
              Start Free Today <span className="text-lg">→</span>
            </button>
          </div>
          <div className="absolute -right-20 -bottom-20 w-64 h-64 bg-white/5 rounded-full"></div>
        </div>
      </section>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4" onClick={() => setIsModalOpen(false)}>
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-100 overflow-hidden relative p-8" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setIsModalOpen(false)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 transition-colors">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
            <div className="text-center mb-6">
              <h2 className="text-2xl font-extrabold text-slate-900">
                {authMode === 'login' ? 'Welcome Back' : 'Create Your Account'}
              </h2>
              <p className="text-sm text-slate-500 mt-1">
                {authMode === 'login' ? 'Log in to manage your active leads.' : 'Start unlocking verified hot leads instantly.'}
              </p>
            </div>
            {message && (
              <div className={`p-3 rounded-lg text-sm font-medium mb-4 text-center ${message.type === 'error' ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}>
                {message.text}
              </div>
            )}
            <form onSubmit={handleAuthSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Email Address</label>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="w-full rounded-lg border-slate-200 text-sm focus:border-[#0052cc] focus:ring-[#0052cc]" placeholder="you@example.com" />
              </div>
              <div>
                <label className="block text-xs font-bold uppercase text-slate-500 mb-1">Password</label>
                <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} className="w-full rounded-lg border-slate-200 text-sm focus:border-[#0052cc] focus:ring-[#0052cc]" placeholder="••••••••" />
              </div>
              <button type="submit" disabled={loading} className="w-full py-3 bg-[#0052cc] text-white font-bold rounded-lg text-sm hover:bg-[#0747a6] transition-colors mt-2 shadow-sm disabled:opacity-50">
                {loading ? 'Processing...' : authMode === 'login' ? 'Sign In' : 'Create Free Account'}
              </button>
            </form>
            <div className="text-center mt-6 pt-4 border-t border-slate-100 text-sm">
              <span className="text-slate-500">{authMode === 'login' ? "Don't have an account?" : 'Already have an account?'}</span>
              <button onClick={() => setAuthMode(authMode === 'login' ? 'signup' : 'login')} className="text-[#0052cc] font-bold ml-1 hover:underline focus:outline-none">{authMode === 'login' ? 'Sign Up Free' : 'Sign In'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
